package org.game.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.game.model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao{

	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			logger.info("Datebase connection established.");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e);
			e.printStackTrace();
		}
		return null;
	}
	
	private int getLatestRegistrationId() {
		try(Connection connection = getConnection()) {
			String sql = "select max(registrationId) from registration";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return 100;
	}
	
	@Override
	public Registration createRegistration(Registration registration) {
		try(Connection connection = getConnection()) {
			
			String query = "insert into registration values(null,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, registration.getCustomerName());
			statement.setString(2,registration.getMobileNo());
			statement.setDouble(3, registration.getRegistrationFees());
			statement.setInt(4, registration.getAge());
			statement.setDouble(5, registration.getActualFees());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Registration successful.");
				logger.info("Registration successful. "+registration.toString());
				
				registration.setRegistrationId(getLatestRegistrationId());
				return registration;
			}else {
				System.out.println("Error occured.");
				logger.error("Error occured.");
			} 
		} catch (SQLException e) {
			logger.error(e);
			e.printStackTrace();
		}
		return null;
	}

}
