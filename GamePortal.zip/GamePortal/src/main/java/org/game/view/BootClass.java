package org.game.view;

import org.game.model.Registration;

public class BootClass {

	public static void main(String[] args) {
		
		do {
			int choice = UserInteraction.getTaskChoiceFromUser();
			switch (choice) {
				case 1:
					Registration registration = UserInteraction.promptRegistration();
					Registration registration2 = UserInteraction.createRegistration(registration);
					if(registration2!=null) {
						UserInteraction.printAcknowledgement(registration2);
					}else {
						System.out.println("nullll");
					}
					break;
				case 2:
					System.out.println("Thank you!");
					System.exit(0);
					break;
				default:
					break;
			}
		}while(UserInteraction.getRepeatConfirmation());

		System.out.println("Thank you!");
		System.exit(0);
	}

	
}
