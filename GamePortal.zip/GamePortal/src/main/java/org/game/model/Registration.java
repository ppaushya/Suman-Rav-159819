package org.game.model;

public class Registration {

	private int registrationId;
	private String customerName;
	private String mobileNo;
	private double registrationFees;
	private int age;
	private double actualFees;
	
	
	public Registration() {
		super();
	}
	public Registration(int registrationId, String customerName, String mobileNo, double registrationFees, int age,
			double actualFees) {
		super();
		this.registrationId = registrationId;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.registrationFees = registrationFees;
		this.age = age;
		this.actualFees = actualFees;
	}
	
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getRegistrationFees() {
		return registrationFees;
	}
	public void setRegistrationFees(double registrationFees) {
		this.registrationFees = registrationFees;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getActualFees() {
		return actualFees;
	}
	public void setActualFees(double actualFees) {
		this.actualFees = actualFees;
	}
	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId + ", customerName=" + customerName + ", mobileNo="
				+ mobileNo + ", registrationFees=" + registrationFees + ", age=" + age + ", actualFees=" + actualFees
				+ "]";
	}
	
	
}
