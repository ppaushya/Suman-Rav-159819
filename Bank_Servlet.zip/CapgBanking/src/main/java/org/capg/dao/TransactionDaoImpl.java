package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao {

		
	@Override
	public List<Transaction> getAllTransactions(Customer customer/*,LocalDate fromdate,LocalDate todate*/) {
		
		List<Transaction> transactions=new ArrayList<>();
		//String str="select * from acc_transaction where customerId=? and transactionDate between ? and ?";
		String str="select * from acc_transaction where customerId=?";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, customer.getCustomerId());
			//statement.setDate(2, java.sql.Date.valueOf(fromdate));
			//statement.setDate(3, java.sql.Date.valueOf(todate));
			
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Transaction transaction=new Transaction();
				
					transaction.setTransactionId(resultSet.getInt(1));
					transaction.setTransactionDate(resultSet.getDate(2).toLocalDate());
					transaction.setTransactionType(resultSet.getString(7));
					transaction.setAmount(resultSet.getDouble(5));
					transaction.setFromAccount(resultSet.getLong(3));
					transaction.setToAccount(resultSet.getLong(4));						
					transaction.setDescription(resultSet.getString(6));
		            transaction.setCustomerId(resultSet.getInt(8));
					transactions.add(transaction);
			
				
			}
		}	catch (SQLException e) {
			
			e.printStackTrace();
		}
		return transactions;
	}
	
	
	@Override
	public void createTransaction(Transaction transaction) {
		
		String sql="insert into acc_transaction values(?,?,?,?,?,?,?,?);";
		
		String sql1="select max(transactionId) from acc_transaction";
		int transactionid=0;
		
		try(Connection connection=getConnection())
		{

			PreparedStatement statement2=connection.prepareStatement(sql1);
		  ResultSet res=statement2.executeQuery();
			if(res.next())
			{
				transactionid=res.getInt(1);
				
				if(transactionid==0)
				{
					transactionid=12345;
				}
				else
					transactionid+=1;
			}
			transaction.setTransactionId(transactionid);
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setLong(1, transaction.getTransactionId());
			statement.setDouble(5, transaction.getAmount());
			statement.setString(7, transaction.getTransactionType());
			statement.setDate(2, java.sql.Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(8, transaction.getCustomerId());
			if(transaction.getFromAccount()!=0)
				statement.setLong(3, transaction.getFromAccount());
			else
				statement.setLong(3, 0);
			if(transaction.getToAccount()!=0)
				statement.setLong(4, transaction.getToAccount());
			else
				statement.setLong(4, 0);
			statement.setString(6, transaction.getDescription());
			
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Transactions table!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	

}
