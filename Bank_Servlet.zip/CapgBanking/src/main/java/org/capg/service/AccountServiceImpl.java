package org.capg.service;

import java.util.Set;

import org.capg.dao.AccountDaoImpl;

import org.capg.dao.IAccountDao;
import org.capg.model.Account;
import org.capg.model.Customer;


public class AccountServiceImpl implements IAccountService {

	private IAccountDao accountDao= new AccountDaoImpl();

	public void createAccount(Account account) {
		
		//System.out.println("Account creation...............");
		accountDao.createAccount(account);
		
	}

	public Set<Account> getAccountsForCustomer(Customer customer) {
		
		return accountDao.getAccountsOfCustomer(customer);
	}
public Set<Account> getAccounts(Customer customer) {
		
		return accountDao.getAccounts(customer);
	}
public Account getAccount(long accountno) {
	return accountDao.getAccount(accountno);
}
	
}
