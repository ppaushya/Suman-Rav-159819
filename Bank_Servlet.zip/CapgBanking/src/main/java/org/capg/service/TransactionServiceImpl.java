package org.capg.service;

import java.time.LocalDate;
import java.util.List;

import java.util.Map;
import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService {

	
	private ITransactionDao transDao=new TransactionDaoImpl();
	
	@Override
	public void createTransaction(Transaction transaction) {
	
		transDao.createTransaction(transaction);
	}

	@Override
	public List<Transaction> getAllTransactions(Customer customer) {
		
		return transDao.getAllTransactions(customer);
	}

	/*@Override
	public List<Transaction> getAllTransactions(Customer customer, LocalDate fromdate, LocalDate todate) {
		
		return transDao.getAllTransactions(customer,fromdate,todate);
	}
	*/
}
