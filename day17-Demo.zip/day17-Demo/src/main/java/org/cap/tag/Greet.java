package org.cap.tag;

import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Greet extends SimpleTagSupport{
	
	private String user;
	private String color;
	

	public void setUser(String user) {
		this.user = user;
	}

	public void setColor(String color) {
		this.color = color;
	}


	@Override
	public void doTag() throws JspException, IOException {
		
		String user_name;
		JspWriter out= getJspContext().getOut();
		
		if(user!=null) {
			user_name=this.user; 
		}
		else
			user_name="Capgemini";
		
	
	
	String GreetingMsg = null;
	LocalTime time=LocalTime.now();
	int hours=time.getHour();
	
	if(hours >1 && hours<=9) {
		
		GreetingMsg="Good Morning";
		}
	if(hours >= 10 && hours<=14) {
		
		GreetingMsg="Good Afternoon";
		}
	if(hours >14 ) {
	
	GreetingMsg="Good Evening";
	}

out.println("<h3> "+GreetingMsg+"<span style=\"color:"+this.color+"\"> "+user_name+" </span></h3>");
	

}}
