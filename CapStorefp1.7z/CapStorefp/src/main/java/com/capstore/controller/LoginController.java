package com.capstore.controller;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.Customer;
import com.capstore.model.Email;
import com.capstore.model.Login;
import com.capstore.service.ILoginService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/v1")
public class LoginController {

	
	@Autowired
	private ILoginService loginService;
	
	
	@PostMapping("/validlogin")
	public ResponseEntity<Login> getLogin (@RequestBody Login login, HttpSession session){
		
		//(@RequestBody Login login,
		System.out.println("dfsgsdfgtsdfgt");
		
		Login loginbean=loginService.getLogin(login.getEmailId(),login.getPassword());
		
		if(loginbean==null)
		{
			return new ResponseEntity<Login>(new Login(),HttpStatus.OK);	
		}
		session.setAttribute("emailId", loginbean.getEmailId());
		Customer customer=loginService.getCustomerId(loginbean.getEmailId());
		session.setAttribute("customerId",customer.getCustomerId() );
		
		return new ResponseEntity<Login>(loginbean,HttpStatus.OK);	
	}
	
	@PostMapping("/forgotPassword")
	public ResponseEntity<Boolean> forgotPassword(@RequestBody String emailId){
		
		
		
		String password="capStore123";
		Login loginbean=loginService.getLoginByEmailId(emailId);
		String generatedPassword=loginbean.getPassword();
		
		try {
            // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            //Add password bytes to digest
            md.update(password.getBytes());
            //Get the hash's bytes
            byte[] bytes = md.digest();
            //This bytes[] has bytes in decimal format;
            //Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get complete hashed password in hex format
            generatedPassword = sb.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
		
		loginService.setPasswordByEmail(emailId,generatedPassword);

		Email mail=new Email();
		mail.setReceiverEmailId(emailId);
		mail.setMessage("Your password is capStore123");
		mail.setImageUrl("");
		//emailService.sendEmail(mail);
		return  new ResponseEntity<Boolean>(false,HttpStatus.OK);
		
		
	}
	
	
}