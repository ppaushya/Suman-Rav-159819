package org.capg.hbms.view;

import java.util.Scanner;

import org.capg.hbms.model.Users;
import org.capg.hbms.util.Utility;


public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	
	Utility utility = new Utility();
	
	public Users userRegistration() {
		
		
		Users user=new Users();
	
		System.out.println("Enter User Id:");
		user.setUser_id(scanner.next());
		
		boolean flag=false;
		do {
		System.out.println("Enter Role[Customer|Employee|Admin]:");
		String role=scanner.next();
		flag=utility.isValidRole(role);
		if(flag==true)
			user.setRole(role);
		else System.out.println("Invalid role. Enter again!!");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter UserName:");
		String user_name=scanner.next();
		flag=utility.isValidUserName(user_name);
		if(flag==true)
			user.setUser_name(user_name);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter Mobile No.:");
		String mobile_no=scanner.next();
		flag=utility.isValidMobileNo(mobile_no);
		if(flag==true)
			user.setMobile_no(mobile_no);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		
		
		do {
		System.out.println("Enter Phone NO.:");
		String phone=scanner.next();
		flag=utility.isValidPhoneNo(phone);
		if(flag==true)
			user.setPhone(phone);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		System.out.println("Enter Address");
		user.setAddress(scanner.next());
		//flag=false;
		
		do {
		System.out.println("Enter Email:");
		String email=scanner.next();
		flag=utility.isValidEmail(email);
		if(flag==true)
			user.setEmail(email);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter Password");
		String password=scanner.next();
		
		
		System.out.println("Re-enter Password");
		String password1=scanner.next();
		
		if(password.equals(password1)) {
			user.setPassword(password);
			flag=true;}
		else {System.out.println("Passwords did not Match");
				flag=false;	}
		}while(flag==false);
		
		return user;
		
		
		
		
		
		
		
	}
}
