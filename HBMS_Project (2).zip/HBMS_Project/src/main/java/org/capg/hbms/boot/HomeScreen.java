package org.capg.hbms.boot;

import java.util.Scanner;

import org.capg.hbms.model.Users;
import org.capg.hbms.view.UserInteraction;

public class HomeScreen {
 
	public static void main(String[] args) {
	 Scanner scanner=new Scanner(System.in); 
	 UserInteraction userInteraction=new UserInteraction();
	 Users user=new Users();
		System.out.println("1) Register\n2)Login\nEnter your Choice:");
		int choice=scanner.nextInt();
		String option;
		do {
			
		if(choice==1) {
			user=userInteraction.userRegistration();
		} else if(choice==2) {
			
			
			
		}else System.out.println("Invalid option");
		
		//System.out.println("Do you wish to continue");
		option=scanner.next();
	}while(option.charAt(0)=='Y'||option.charAt(0)=='y');	
	}

}
