function validate()
{
	var flag= false;
	var userName=form.userName.value;
	var userPassword=form.userPwd.value;
	
	if(userName==""||userName==null)
	{
		document.getElementById("userErrMsg").innerHTML="Please enter a valid username.";
		flag=false;
	}
	else if(userPassword==""||userPassword==null)
	{
		document.getElementById("pwdErrMsg").innerHTML="Please enter a valid password.";
		flag=false;
	}
	else{
		
		document.getElementById('pwdErrMsg').innerHTML="";
		document.getElementById('userErrMsg').innerHTML="";
		flag=true;
	}
	return flag;
}
