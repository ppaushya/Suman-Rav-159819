package out.capg.demo;

public class MainClass6 {

	public static void main(String[] args) {
		
		
		
	}

}
