package out.capg.demo;

public class Address {
	private String stName;
	private String area;
	private String city;
	private String state;
	
	public Address() {
		
	}
	public Address(String stName, String area, String city, String state) {
		super();
		this.stName = stName;
		this.area = area;
		this.city = city;
		this.state = state;
	}
	
	public String getStName() {
		return stName;
	}
	
	public void setStName(String stName) {
		this.stName = stName;
	}
	
	public String getArea() {
		return area;
	}
	
	public void setArea(String area) {
		this.area = area;
	}
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	

}
