package out.capg.demo;

import java.util.Date;

public class Transactions {
	
	private int transactionId;
	private Date transactionDate;
	private String transactionType;
	private Double amount;
	private String transactionSummary,accountType;
	
	public Transactions() {
		
	}
	
	public Transactions(int transactionId, Date transactionDate, String transactionType, Double amount,
			
			String transactionSummary, String accountType) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.transactionType = transactionType;
		this.amount = amount;
		this.transactionSummary = transactionSummary;
		this.accountType = accountType;
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	public Date getTransactionDate() {
		return transactionDate;
	}
	
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public Double getAmount() {
		return amount;
	}
	
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	public String getTransactionSummary() {
		return transactionSummary;
	}
	
	public void setTransactionSummary(String transactionSummary) {
		this.transactionSummary = transactionSummary;
	}
	
	public String getAccountType() {
		return accountType;
	}
	
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	

}
