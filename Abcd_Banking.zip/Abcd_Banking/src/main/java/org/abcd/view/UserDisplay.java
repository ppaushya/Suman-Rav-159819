package org.abcd.view;

import java.util.List;
import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.AccountType;
import org.abcd.model.Customer;
import org.abcd.model.Transaction;
import org.abcd.service.AccountServiceImpl;
import org.abcd.service.IAccountService;

public class UserDisplay {

	public static void printCustomers(List<Customer> customers) {
	
		System.out.println("CustomerId\tName\tEmail\t\t\tMobileNo");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()+"\t"+customer.getFirstName()+"\t"+customer.getEmailId()+"\t"+customer.getMobileNo());
		}
		
	}
	
	public static void printAccountsOfCustomer(Customer customer) {
		Set<Account> accounts = customer.getAccounts();
		System.out.println("Available accounts: ");
		for(Account account:accounts) {
			System.out.println(account.getAccountNumber()+"\t"+account.getAccountType());
		}
	}
	
	public static void printTransactionsOfCustomer(Set<Transaction> transactions) {		
		
		System.out.println("Date\t\tAccount\t\tTransaction\tAmount");
		
		for(Transaction transaction:transactions) {
			String str = transaction.getTransactionDate()
					+"\t"+transaction.getFromAccount().getAccountNumber()
					+"\t"+transaction.getTransactionType()
					+(transaction.getTransactionType().equals("Fund Transfer")? "\t" : "\t\t")+
					+transaction.getAmount();
			System.out.println(str);
		}
	
	}
	
	public static void printCurrentBalance(double balance) {
		System.out.println("Current balance: "+balance);
	}
	
	public static void printAllAccountTypes() {
		AccountType[] accountTypes = AccountType.values();
		int count=0;
		for(AccountType accountType : accountTypes) {
			System.out.println((++count)+". "+accountType);
		}
	}
	
	public static void printMessage(String message) {
		System.out.println(message);
	}
}
