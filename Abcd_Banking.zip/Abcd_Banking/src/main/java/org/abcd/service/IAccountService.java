package org.abcd.service;

import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.Customer;

public interface IAccountService {

	public boolean createAccount(Account account) ;
	
	public Set<Account> getAllAccounts();
	
	public Account getAccountFromAccountId(long customerId, long accountId);

	public double getCurrentBalanceOfAccount(Account account);
}
