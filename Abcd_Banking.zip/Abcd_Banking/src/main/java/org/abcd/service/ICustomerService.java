package org.abcd.service;

import java.util.List;

import org.abcd.model.Customer;

public interface ICustomerService {

	public boolean createCustomer(Customer customer) ;
	
	public List<Customer> getAllCustomers();
	
	public Customer getCustomerFromCustomerId(long customerId);
}
