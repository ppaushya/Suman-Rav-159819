package org.abcd.service;

import java.util.Set;

import org.abcd.dao.IAccountDao;
import org.abcd.dao.ITransactionDao;
import org.abcd.dao.TransactionDaoImpl;
import org.abcd.dao.TransactionDbImpl;
import org.abcd.model.Account;
import org.abcd.model.Customer;
import org.abcd.model.Transaction;

public class TransactionServiceImpl implements ITransactionService{
	
//	ITransactionDao transactionDao = new TransactionDaoImpl();
	ITransactionDao transactionDao = new TransactionDbImpl();
	
	public Set<Transaction> getAllTransactions() {
		return transactionDao.getAllTransactions();
	}
	
	public Set<Transaction> getAllTransactionsOfCustomer(Customer customer) {
		return transactionDao.getAllTransactionsOfCustomer(customer);
	}
	
	public Set<Transaction> getAllTransactionsOfAccount(Account Account) {
		return transactionDao.getAllTransactionsOfAccount(Account);
	}
	
	public void createTransaction(Transaction transaction) {
		transactionDao.createTransaction(transaction);		
	}

}
