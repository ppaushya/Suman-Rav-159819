package org.abcd.model;

public enum AccountType {
	SAVING,CURRENT,FD,RD;
}
