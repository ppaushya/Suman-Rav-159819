package org.abcd.dao;

import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.Customer;
import org.abcd.model.Transaction;

public interface ITransactionDao {
	
	public Set<Transaction> getAllTransactions();
	
	public Set<Transaction> getAllTransactionsOfCustomer(Customer customer);
	
	public Set<Transaction> getAllTransactionsOfAccount(Account Account);
		
	public void createTransaction(Transaction transaction);
}
