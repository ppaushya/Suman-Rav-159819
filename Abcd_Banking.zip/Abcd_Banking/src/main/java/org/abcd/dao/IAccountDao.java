package org.abcd.dao;

import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.Customer;

public interface IAccountDao {
	
	public Set<Account> getAllAccounts();
	
	public Set<Long> getAllAccountIds();
	
	public Account getAccountFromAccountId(long customerId, long accountId);
	
	public void createAccount(Account account);
}
