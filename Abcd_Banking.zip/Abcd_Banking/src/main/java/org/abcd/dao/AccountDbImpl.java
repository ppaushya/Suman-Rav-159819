package org.abcd.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.AccountType;
import org.abcd.model.Address;
import org.abcd.model.Customer;

public class AccountDbImpl implements IAccountDao{

	private Customer customer;
	
	public AccountDbImpl(Customer customer) {
		super();
		this.customer = customer;
	}

	private Connection getConnection() {
		Connection connection = null;
		try {
			File dbPropertiesFile = new File("mysqldb.properties");
			FileInputStream inputStream = new FileInputStream(dbPropertiesFile);
			Properties properties = new Properties();
			properties.load(inputStream);
			
/*			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
			return connection;
*/			
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties.getProperty("url")
					, properties.getProperty("user"), properties.getProperty("password"));
			return connection;
		} catch (ClassNotFoundException | SQLException | IOException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Set<Account> getAllAccounts() {
		Set<Account> accounts = new HashSet<>();
		try(Connection connection = getConnection()) {
			String sql = "select * from account where customerId=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Account account = new Account();
				account.setAccountNumber(resultSet.getLong("accountNumber"));
				account.setAccountType(AccountType.valueOf(resultSet.getString("accountType")));
				account.setOpeningDate(resultSet.getDate("openingDate").toLocalDate());
				account.setOpeningBalance(resultSet.getDouble("openingBalance"));
				account.setDescription(resultSet.getString("description"));
				
				accounts.add(account);
			}
			return accounts;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account getAccountFromAccountId(long customerId,long accountId) {
		try(Connection connection = getConnection()) {
			String sql = "select * from account where accountNumber=? and customerId=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, accountId);
			statement.setLong(2, customerId);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Account account = new Account();
				account.setAccountNumber(resultSet.getLong("accountNumber"));
				account.setAccountType(AccountType.valueOf(resultSet.getString("accountType")));
				account.setOpeningDate(resultSet.getDate("openingDate").toLocalDate());
				account.setOpeningBalance(resultSet.getDouble("openingBalance"));
				account.setDescription(resultSet.getString("description"));

				return account;
			}
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void createAccount(Account account) {
		try(Connection connection = getConnection()) {
				
			String query = "insert into account values(null,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setLong(1, customer.getCustomerId());
			statement.setString(2, account.getAccountType().toString());
			statement.setDate(3,Date.valueOf(account.getOpeningDate()));
			statement.setDouble(4, account.getOpeningBalance());
			statement.setString(5, account.getDescription());
			
			if(statement.executeUpdate()>0) {
//				customer.getAccounts().add(account);
				customer.setAccounts(getAllAccounts());
				System.out.println("Account inserted.");
			}else {
				System.out.println("Error occured.");
			} 
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

	@Override
	public Set<Long> getAllAccountIds() {
		Set<Long> accountIds = new HashSet<>();
		try(Connection connection = getConnection()) {
			String sql = "select accountNumber from account where customerId=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				accountIds.add(resultSet.getLong("accountNumber"));
			}
			return accountIds;
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

}
