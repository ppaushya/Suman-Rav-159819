package org.abcd.dao;

import java.util.HashSet;
import java.util.Set;

import org.abcd.model.Account;
import org.abcd.model.Customer;
import org.abcd.util.IdGenerator;

public class AccountDaoImpl implements IAccountDao{

	private Customer customer;
	
	public AccountDaoImpl(Customer customer) {
		super();
		this.customer = customer;
	}

	public Set<Account> getAllAccounts() {
		return customer.getAccounts();
	}

	public Account getAccountFromAccountId(long customerId, long accountId) {
		Set<Account> accounts = customer.getAccounts();
		for(Account account:accounts) {
			if(account!=null) {
				if(account.getAccountNumber()==accountId) {
					return account;
				}
			}
		}
		return null;
	}

	public void createAccount(Account account) {
		account.setAccountNumber(IdGenerator.generateAccountNumber());
		customer.getAccounts().add(account);
	}

	@Override
	public Set<Long> getAllAccountIds() {
		Set<Long> accountIds = new HashSet<>();
		for(Account account:customer.getAccounts()) {
			accountIds.add(account.getAccountNumber());
		}
		return accountIds;
	}

}
