package org.abcd.dao;

import java.util.List;

import org.abcd.model.Customer;

public interface ICustomerDao {

	public List<Customer> getAllCustomers();
	
	public void createCustomer(Customer customer);
	
	public Customer getCustomerFromCustomerId(long customerId);
}
