package org.abc.util;

public class Utility {
	
	public static int generateRandomNumber() {
		
		return (int) (Math.random())*10000/100; 
		
	}
	public static boolean isValidCustomerName(String Name) {
		
		return Name.matches("[a-zA-Z]{3,}");
		
	}
	public static boolean isValidEmail(String email) {
		
		return email.matches("[a-z]+@[a-z].[com]");
	}
	public static boolean isValidMobileNo(String number) {
		
		return number.matches("[1-9]{1}[0-9]{9}");
	}
	
	public static boolean isValidDoB(String DOB) {
		
		return DOB.matches("[0-9]{1}[1-9]{1}-[0-9]{1}[1-9]{1}-[1-9]{1}[0-9]{3}");
	}
	
	public static boolean isValidPIN(String PIN) {
		
		return PIN.matches("[0-9]{6}");
	}

}
