package org.abc.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.abc.model.Address;
import org.abc.model.Customer;

public class CustomerDaoImpl implements ICustomerDao  {
	
	public static List<Customer> customers=dummyDb();
	
	
	
	
	

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	private static List<Customer> dummyDb() {
		
		ArrayList<Customer> customers=new ArrayList<>();
		Address address1=new Address("10,downing St", "andheri St", "Chennai", "TN", "208976");
		customers.add(new Customer(121,"pika","bdw","ehg@yahoo.com", "5657576868l", LocalDate.of(2001,11,21),  address1));
		Address address2=new Address("11,downing St", "andheri St", "Chennai", "TN", "208976");
		customers.add(new Customer(122,"pikachu","bdwnmm","dehd@gmail.com", "7878796857l", LocalDate.of(2007,12,21),  address2));
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		 customers.add(customer);
		
	}

}
