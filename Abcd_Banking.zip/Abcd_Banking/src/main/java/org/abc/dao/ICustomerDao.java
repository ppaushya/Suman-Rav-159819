package org.abc.dao;
import org.abc.util.*;

import java.util.List;

import org.abc.model.Customer;
public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);

}
