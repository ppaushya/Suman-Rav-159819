package org.abc.model;

import java.time.LocalDate;

public class Transaction {
		 
			int transactionId;
			LocalDate transactionDate;
			String debit;
			String credit;
			Double amount;
			Account fromAccount;
			Account toAccount;
			String discription;
			
			
			public Transaction() {
				
			}
			
			public Transaction(int transactionId, LocalDate transactionDate, String debit, String credit, Double amount,
					Account fromAccount, Account toAccount, String discription) {
				super();
				this.transactionId = transactionId;
				this.transactionDate = transactionDate;
				this.debit = debit;
				this.credit = credit;
				this.amount = amount;
				this.fromAccount = fromAccount;
				this.toAccount = toAccount;
				this.discription = discription;
			}

			public int getTransactionId() {
				return transactionId;
			}
			
			public void setTransactionId(int transactionId) {
				this.transactionId = transactionId;
			}
			
			public LocalDate getTransactionDate() {
				return transactionDate;
			}
			
			public void setTransactionDate(LocalDate transactionDate) {
				this.transactionDate = transactionDate;
			}
			
			public String getDebit() {
				return debit;
			}
			
			public void setDebit(String debit) {
				this.debit = debit;
			}
			
			public String getCredit() {
				return credit;
			}
			
			public void setCredit(String credit) {
				this.credit = credit;
			}
			
			public Double getAmount() {
				return amount;
			}
			
			public void setAmount(Double amount) {
				this.amount = amount;
			}
			
			public Account getFromAccount() {
				return fromAccount;
			}
			
			public void setFromAccount(Account fromAccount) {
				this.fromAccount = fromAccount;
			}
			
			public Account getToAccount() {
				return toAccount;
			}
			
			public void setToAccount(Account toAccount) {
				this.toAccount = toAccount;
			}
			
			public String getDiscription() {
				return discription;
			}
			
			public void setDiscription(String discription) {
				this.discription = discription;
			}

			@Override
			public String toString() {
				return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
						+ ", debit=" + debit + ", credit=" + credit + ", amount=" + amount + ", fromAccount="
						+ fromAccount + ", toAccount=" + toAccount + ", discription=" + discription + "]";
			}
			
			
			
			
}
