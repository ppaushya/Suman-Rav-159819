package org.abc.model;

public enum AccountType {
	
	SAVING,WITHDRAWL,RD,FD;

}
