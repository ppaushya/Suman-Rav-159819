package org.abc.model;

import java.time.LocalDate;

public class Account {
	
	private long accoountNo;
	private AccountType accountType;
	private LocalDate openingDate;
	private double openingBalance;
	private String discription;
	
	public Account() {
		
	}
	public Account(long accoountNo, AccountType accountType, LocalDate openingDate, double openingBalance,
			String discription) {
		super();
		this.accoountNo = accoountNo;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.openingBalance = openingBalance;
		this.discription = discription;
	}

	public long getAccoountNo() {
		return accoountNo;
	}
	
	public void setAccoountNo(long accoountNo) {
		this.accoountNo = accoountNo;
	}
	
	public AccountType getAccountType() {
		return accountType;
	}
	
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	
	public double getOpeningBalance() {
		return openingBalance;
	}
	
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	
	public String getDiscription() {
		return discription;
	}
	
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	

	@Override
	public String toString() {
		return "Account [accoountNo=" + accoountNo + ", accountType=" + accountType + ", openingDate=" + openingDate
				+ ", openingBalance=" + openingBalance + ", discription=" + discription + "]";
	}
	
	

}
