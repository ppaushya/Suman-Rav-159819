package org.abc.boot;

import java.util.List;
import java.util.Scanner;

import org.abc.model.Customer;
import org.abc.service.CustomerServiceImpl;
import org.abc.view.UserInterface;

public class BootClass {
	
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		CustomerServiceImpl customerservice=new CustomerServiceImpl();
		UserInterface userinterface=new UserInterface();
		 int choice;
		 String option;
		 
		 do {
			 System.out.println("1.Create Customer:");
			 System.out.println("2.List Customers ");
			 System.out.println("Enter your choice");
			 choice=scanner.nextInt();
			 
			 
			 switch(choice) {
			 
			 case 1:
				  
				 int count=customerservice.getAllCustomers().size();
				 Customer customer=UserInterface.getCustomerDetails(); 
				 
				 
				 
				 if(count==customerservice.getAllCustomers().size()) {
					 //UserInterface.printError("invalid details! Please try again");
					 System.out.println();
				 }
			break; 
		   
		    case 2:
		    	
		    	List<Customer> customers=customerservice.getAllCustomers();
		    	UserInterface.printCustomers(customers);
		    	break;
		    default:
		    	System.out.println("sorry! invalid choice");
		    	System.exit(0);
			 } 	
			System.out.println("Do you wish to continue? [y|n]:");
			option=scanner.next();
			
			  }while((option.charAt(0)=='y')||( option.charAt(0)=='Y'));
			 
			 
			 
			 
		 }
		
		

}
