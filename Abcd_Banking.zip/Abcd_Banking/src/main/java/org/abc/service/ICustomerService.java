package org.abc.service;

import java.util.List;

import org.abc.model.Customer;

public interface ICustomerService {
	
	public void createCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
	

}
