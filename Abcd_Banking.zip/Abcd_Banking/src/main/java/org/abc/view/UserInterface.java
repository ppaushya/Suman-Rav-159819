package org.abc.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.abc.model.Address;

import org.abc.model.Customer;
import org.abc.util.*;





public class UserInterface {
	
	Scanner scan=new Scanner(System.in);
		public static Customer getCustomerDetails() {
			
			Customer customer=new Customer();
			customer.setCustomerId(Utility.generateRandomNumber());
			
			customer.setFirstName(getCustomerFirstName() );
			customer.setLastName(getCustomerLastName());
			customer.setEmailId(getEmailId());
			customer.setMobileNo(getMobileNo());
			customer.setDateOfBirth(DateOfBirth());
			//customer.setAddress(getAddress());
			
			return customer;
			}
		
		public static String getCustomerFirstName() {
			boolean flag;
			String fname;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter first name:");
			
			do {
				
				fname=scan.next();
				flag=Utility.isValidCustomerName(fname);
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid name");
				}
				
				return fname;	
				
			}while(flag==false);
			}
		
		
		public static String getCustomerLastName() {
			
			boolean flag;
			String fname;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter last name:");
			
			do {
				
				fname=scan.next();
				flag=Utility.isValidCustomerName(fname);
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid last name");
				}
				
				return fname;	
				
			}while(flag==false);
			}
		
		
		public static String getEmailId() {	
			boolean flag;
			String fname;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Email Id:");
			
			do {
				
				fname=scan.next();
				flag=Utility.isValidEmail(fname);
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid email Id");
				}
				
				return fname;	
				
			}while(flag==false);
			}
		
		public static String getMobileNo() {
			
			boolean flag;
			String fname;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter mobile no:");
			
			do {
				
				fname=scan.next();
				flag=Utility.isValidMobileNo(fname);
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid mobile no");
				}
				
				return(fname);	
				
			}while(flag==false);
			}
		
		
		public static LocalDate DateOfBirth() {
			
			boolean flag;
			String Dob;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Date of Birth:");
			
			do {
				
				Dob=scan.next();
				flag=Utility.isValidDoB(Dob);
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid Date");
				}
				
				
				String dateParts[] = Dob.split("-"); 
				return LocalDate.of(Integer.parseInt(dateParts[2]), 
						Integer.parseInt(dateParts[1]),
						Integer.parseInt(dateParts[0]));	
				
				}while(flag==false);
			
			
			
		}
		
		

		public Address getAddressDetails() {
			Address address=new Address();
			System.out.println("Enter AddressLine1:");
			address.setStreet(scan.next());
			System.out.println("Enter AddressLine2:");
			address.setArea(scan.next()); 
			System.out.println("Enter City:");
			address.setCity(scan.next());
			System.out.println("Enter State:");
			address.setState(scan.next());
			
			address.setPinCode( getPinCode());
			return address;
		}
		
		public String  getPinCode() {
			
			
			boolean flag;
			String fname;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter the PIN:");
			
			do {
				
				fname=scan.next();
				flag=fname.matches("[0-9]{6}");
				 
				if(flag==false)
					
				{
					System.out.println("Please enter a valid PIN");
				}
				
				 	return(fname);	
				}while(flag==false);
				}
	
	public static void main(String[] args) {
		
	UserInterface obj=new UserInterface();
	obj.getCustomerDetails();
		

	}

	public static void printError(String message) {
		
		System.out.println(message);
		
	}

	public static void printCustomers(List<Customer> customers) {
		
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("--------------------------------------------------");
		
		for(Customer customer:customers) {
			
			System.out.println(customer.getCustomerId()+"\t\t" +customer.getFirstName()+" "+
			customer.getLastName()+ "\t\t" + customer.getMobileNo()+" "+customer.getEmailId());
			
		}
		
		
		
		
	}

}
