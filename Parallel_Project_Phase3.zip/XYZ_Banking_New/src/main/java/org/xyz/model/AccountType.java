package org.xyz.model;

public enum AccountType {
	SAVINGS,CURRENT,FD,RD;
}
