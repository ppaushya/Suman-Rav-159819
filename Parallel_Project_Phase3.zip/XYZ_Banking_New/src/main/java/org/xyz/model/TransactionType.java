package org.xyz.model;

public enum TransactionType {
	DEPOSITE,WITHDRAWAL,FUND_TRANSFER
}
